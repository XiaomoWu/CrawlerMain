# -*- coding: utf-8 -*-
from .connection import (  # NOQA
    get_redis,
    get_redis_from_settings,
)


__author__ = 'Rolando Espinoza'
__email__ = 'rolando at rmax.io'
__version__ = '0.7.0-dev'
